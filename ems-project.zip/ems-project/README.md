
# Employee Management System (EMS) — Full-Stack Starter

This is a runnable starter aligned to your BRS/SRS/FRS/HLD/LLD/ERD:
- **Backend**: Node.js, Express, Sequelize ORM, JWT-based auth & RBAC, SQLite (switchable to Postgres/MySQL)
- **Frontend**: React + Vite with basic pages (Login, Dashboard, Employees, Attendance, Leaves)

## How to run (local)
1) Backend
```
cd ems-backend
cp .env.example .env
npm install
npm run dev
```
2) Frontend (in a new terminal)
```
cd ems-frontend
npm install
npm run dev
```
Login page includes a **Quick Register** to create an Admin user for testing.

> NOTE: This is a functional starter. Extend routes, validations, and UI to cover payroll, performance, reporting, MFA, and other non-functional requirements from your docs.
