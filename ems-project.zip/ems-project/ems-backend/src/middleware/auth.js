
import jwt from 'jsonwebtoken';
import { config } from '../config.js';
import { User, Role } from '../models/index.js';

export function auth(required = true) {
  return async (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      if (!required) return next();
      return res.status(401).json({ message: 'Missing Authorization header' });
    }
    try {
      const token = authHeader.replace('Bearer ', '');
      const payload = jwt.verify(token, config.jwtSecret);
      const user = await User.findByPk(payload.sub, { include: Role });
      if (!user) return res.status(401).json({ message: 'Invalid token user' });
      req.user = { id: user.id, role: user.Role?.name || 'Employee' };
      next();
    } catch (e) {
      return res.status(401).json({ message: 'Invalid/expired token' });
    }
  };
}

export function requireRoles(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ message: 'Unauthenticated' });
    if (!roles.includes(req.user.role)) return res.status(403).json({ message: 'Forbidden' });
    next();
  };
}
