
import { DataTypes } from 'sequelize';
export default (sequelize) => {
  const Attendance = sequelize.define('Attendance', {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    employeeId: { type: DataTypes.INTEGER, allowNull: false },
    date: { type: DataTypes.DATEONLY, allowNull: false },
    clockIn: { type: DataTypes.TIME },
    clockOut: { type: DataTypes.TIME },
    workingHours: { type: DataTypes.DECIMAL(5,2) },
    status: { type: DataTypes.STRING } // Present, Absent, Late, Early Out
  }, { tableName: 'attendance' });
  return Attendance;
};
