
import { sequelize } from '../db.js';
import UserModel from './user.js';
import DepartmentModel from './department.js';
import RoleModel from './role.js';
import EmployeeModel from './employee.js';
import AttendanceModel from './attendance.js';
import LeaveModel from './leave.js';
import PayrollModel from './payroll.js';
import PerformanceModel from './performance.js';

export const User = UserModel(sequelize);
export const Department = DepartmentModel(sequelize);
export const Role = RoleModel(sequelize);
export const Employee = EmployeeModel(sequelize);
export const Attendance = AttendanceModel(sequelize);
export const Leave = LeaveModel(sequelize);
export const Payroll = PayrollModel(sequelize);
export const Performance = PerformanceModel(sequelize);

// Relations
Role.hasMany(User, { foreignKey: 'roleId' });
User.belongsTo(Role, { foreignKey: 'roleId' });

Department.hasMany(Employee, { foreignKey: 'departmentId' });
Employee.belongsTo(Department, { foreignKey: 'departmentId' });

Role.hasMany(Employee, { foreignKey: 'roleId' });
Employee.belongsTo(Role, { foreignKey: 'roleId' });

Employee.hasMany(Attendance, { foreignKey: 'employeeId' });
Attendance.belongsTo(Employee, { foreignKey: 'employeeId' });

Employee.hasMany(Leave, { foreignKey: 'employeeId' });
Leave.belongsTo(Employee, { foreignKey: 'employeeId' });

Employee.hasOne(Payroll, { foreignKey: 'employeeId' });
Payroll.belongsTo(Employee, { foreignKey: 'employeeId' });

Employee.hasMany(Performance, { foreignKey: 'employeeId' });
Performance.belongsTo(Employee, { foreignKey: 'employeeId' });

export async function syncModels() {
  await sequelize.sync();
}
