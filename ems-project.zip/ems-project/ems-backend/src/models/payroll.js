
import { DataTypes } from 'sequelize';
export default (sequelize) => {
  const Payroll = sequelize.define('Payroll', {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    employeeId: { type: DataTypes.INTEGER, allowNull: false, unique: true },
    salary: { type: DataTypes.DECIMAL(10,2) },
    bonuses: { type: DataTypes.DECIMAL(10,2), defaultValue: 0 },
    deductions: { type: DataTypes.DECIMAL(10,2), defaultValue: 0 },
    netSalary: { type: DataTypes.DECIMAL(10,2) },
    paymentDate: { type: DataTypes.DATEONLY }
  }, { tableName: 'payroll' });
  return Payroll;
};
