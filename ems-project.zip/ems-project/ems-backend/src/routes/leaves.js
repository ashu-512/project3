
import { Router } from 'express';
import { Leave } from '../models/index.js';
import { body, validationResult } from 'express-validator';

const router = Router();

router.get('/', async (req, res) => {
  const rows = await Leave.findAll({ order: [['startDate','DESC']] });
  res.json(rows);
});

router.post('/',
  body('employeeId').isInt(),
  body('leaveType').isString(),
  body('startDate').isISO8601(),
  body('endDate').isISO8601(),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    const created = await Leave.create(req.body);
    res.status(201).json(created);
  }
);

router.put('/:id/approve', async (req, res) => {
  const row = await Leave.findByPk(req.params.id);
  if (!row) return res.status(404).json({ message: 'Not found' });
  await row.update({ status: 'Approved' });
  res.json(row);
});

router.put('/:id/reject', async (req, res) => {
  const row = await Leave.findByPk(req.params.id);
  if (!row) return res.status(404).json({ message: 'Not found' });
  await row.update({ status: 'Rejected' });
  res.json(row);
});

export default router;
