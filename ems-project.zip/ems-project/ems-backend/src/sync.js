
import { sequelize } from './db.js';
import { syncModels } from './models/index.js';

(async () => {
  await sequelize.authenticate();
  await syncModels();
  console.log('Database synced');
  process.exit(0);
})();
