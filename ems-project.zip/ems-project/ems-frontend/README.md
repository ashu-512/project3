
# EMS Frontend (React + Vite)

## Quick start
```bash
cd ems-frontend
npm install
npm run dev
```
The dev server proxies `/api` to the backend at `http://localhost:4000`.
